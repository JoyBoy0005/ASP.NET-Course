﻿namespace DeleteMe
{
    internal class Program
    {
        static int Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            return 1;
        }
    }
}