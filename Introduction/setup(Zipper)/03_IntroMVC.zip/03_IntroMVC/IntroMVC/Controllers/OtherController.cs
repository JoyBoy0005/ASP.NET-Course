﻿using IntroMVC.Models;
using Microsoft.AspNetCore.Mvc;

namespace IntroMVC.Controllers
{
    public class OtherController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [Route("stuff/{year:min(2020)}/{month:range(1,12)}/{key}")]
        public IActionResult Details(int year, int month, string key)
        {
            ViewBag.year = year;
            ViewData["MONTH"] = month;
            ViewBag.key = key;
            return View();
        }

        public IActionResult PageOne()
        {
            var person = new Person
            {
                Id = 1,
                FirstName = "Bob",
                LastName = "Loblaw",
                DateOfBirth = DateOnly.FromDateTime(DateTime.Now.AddDays(-7500)),
            };
            return View(person);
        }
    }
}